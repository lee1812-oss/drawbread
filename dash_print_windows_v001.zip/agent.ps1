﻿#requires -Version 5.1
<#
  DrawbreadAutoPrint agent (Windows PowerShell 5.1, no admin rights)
  - Listens only on 127.0.0.1:17861 (TCP, minimal HTTP). Origin must be https://lee1812-oss.github.io
  - Admin key and API token are stored with DPAPI (CurrentUser only).
  - Scheduled prints are checked every 30 s, even when the dashboard browser is closed.
  Test switches (do not use in production): -Root <folder> -DryRun -NoPopup -PairCode 123456 -SelfTest -Port <n>
#>
[CmdletBinding()]
param(
    [string]$Root = '',
    [switch]$DryRun,
    [switch]$NoPopup,
    [string]$PairCode = '',
    [switch]$SelfTest,
    [int]$Port = 17861
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Security

$script:Version = '1.0.0'
$script:AllowedOrigin = 'https://lee1812-oss.github.io'
$script:RemoteBase = 'https://lee1812-oss.github.io/drawbread/'
$script:MaxBody = 131072
$script:GraceMinutes = 30
$script:MaxSchedules = 10
$script:MaxPairFails = 5
$script:DryRunGlobal = [bool]$DryRun
$script:Utf8 = New-Object Text.UTF8Encoding($false)

$script:Base = if ($Root) { $Root } else { Join-Path $env:LOCALAPPDATA 'DrawbreadAutoPrint' }
$script:CfgPath = Join-Path $script:Base 'config.json'
$script:KeyPath = Join-Path $script:Base 'key.dpapi'
$script:TokPath = Join-Path $script:Base 'token.dpapi'
$script:HistPath = Join-Path $script:Base 'history.json'
$script:PidPath = Join-Path $script:Base 'agent.pid'
$script:LogPath = Join-Path $script:Base 'logs\agent.log'

$script:Token = $null
$script:Paused = $false
$script:Cfg = $null
$script:Records = @()
$script:PendingCode = ''
$script:PairExpires = [DateTime]::MinValue
$script:PairFails = 0
$script:IdxCache = $null
$script:IdxAt = [DateTime]::MinValue
$script:RemoteErrorAt = [DateTime]::MinValue
$script:Notice = @{}
$script:LastReason = @{}
$script:PrintStarted = $false

$script:CsSource = @'
using System;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

public static class DapCrypto
{
    [StructLayout(LayoutKind.Sequential)]
    public struct AuthInfo
    {
        public int cbSize;
        public int dwInfoVersion;
        public IntPtr pbNonce;
        public int cbNonce;
        public IntPtr pbAuthData;
        public int cbAuthData;
        public IntPtr pbTag;
        public int cbTag;
        public IntPtr pbMacContext;
        public int cbMacContext;
        public int cbAAD;
        public long cbData;
        public int dwFlags;
    }

    [DllImport("bcrypt.dll", CharSet = CharSet.Unicode)]
    static extern uint BCryptOpenAlgorithmProvider(out IntPtr phAlgorithm, string pszAlgId, string pszImplementation, uint dwFlags);

    [DllImport("bcrypt.dll")]
    static extern uint BCryptCloseAlgorithmProvider(IntPtr hAlgorithm, uint dwFlags);

    [DllImport("bcrypt.dll", CharSet = CharSet.Unicode)]
    static extern uint BCryptSetProperty(IntPtr hObject, string pszProperty, byte[] pbInput, int cbInput, uint dwFlags);

    [DllImport("bcrypt.dll")]
    static extern uint BCryptGenerateSymmetricKey(IntPtr hAlgorithm, out IntPtr phKey, IntPtr pbKeyObject, int cbKeyObject, byte[] pbSecret, int cbSecret, uint dwFlags);

    [DllImport("bcrypt.dll")]
    static extern uint BCryptDestroyKey(IntPtr hKey);

    [DllImport("bcrypt.dll")]
    static extern uint BCryptDecrypt(IntPtr hKey, byte[] pbInput, int cbInput, ref AuthInfo pPaddingInfo, byte[] pbIV, int cbIV, byte[] pbOutput, int cbOutput, out int pcbResult, uint dwFlags);

    [DllImport("bcrypt.dll")]
    static extern uint BCryptEncrypt(IntPtr hKey, byte[] pbInput, int cbInput, ref AuthInfo pPaddingInfo, byte[] pbIV, int cbIV, byte[] pbOutput, int cbOutput, out int pcbResult, uint dwFlags);

    static void Check(uint status, string where)
    {
        if (status != 0) throw new CryptographicException(where + " 0x" + status.ToString("X8"));
    }

    static byte[] Gcm(bool encrypt, byte[] key, byte[] nonce, byte[] input, byte[] tag)
    {
        IntPtr hAlg = IntPtr.Zero;
        IntPtr hKey = IntPtr.Zero;
        GCHandle gN = GCHandle.Alloc(nonce, GCHandleType.Pinned);
        GCHandle gT = GCHandle.Alloc(tag, GCHandleType.Pinned);
        try
        {
            Check(BCryptOpenAlgorithmProvider(out hAlg, "AES", null, 0), "open");
            byte[] mode = Encoding.Unicode.GetBytes("ChainingModeGCM\0");
            Check(BCryptSetProperty(hAlg, "ChainingMode", mode, mode.Length, 0), "mode");
            Check(BCryptGenerateSymmetricKey(hAlg, out hKey, IntPtr.Zero, 0, key, key.Length, 0), "key");
            AuthInfo info = new AuthInfo();
            info.cbSize = Marshal.SizeOf(typeof(AuthInfo));
            info.dwInfoVersion = 1;
            info.pbNonce = gN.AddrOfPinnedObject();
            info.cbNonce = nonce.Length;
            info.pbTag = gT.AddrOfPinnedObject();
            info.cbTag = tag.Length;
            byte[] output = new byte[input.Length];
            int got;
            if (encrypt)
                Check(BCryptEncrypt(hKey, input, input.Length, ref info, null, 0, output, output.Length, out got, 0), "enc");
            else
                Check(BCryptDecrypt(hKey, input, input.Length, ref info, null, 0, output, output.Length, out got, 0), "dec");
            return output;
        }
        finally
        {
            if (hKey != IntPtr.Zero) BCryptDestroyKey(hKey);
            if (hAlg != IntPtr.Zero) BCryptCloseAlgorithmProvider(hAlg, 0);
            gN.Free();
            gT.Free();
        }
    }

    public static byte[] AesGcmDecrypt(byte[] key, byte[] nonce, byte[] ct, byte[] tag)
    {
        return Gcm(false, key, nonce, ct, tag);
    }

    public static byte[] AesGcmEncrypt(byte[] key, byte[] nonce, byte[] pt, byte[] tagOut)
    {
        return Gcm(true, key, nonce, pt, tagOut);
    }

    public static byte[] Pbkdf2Sha256(byte[] password, byte[] salt, int iterations, int dkLen)
    {
        byte[] result = new byte[dkLen];
        int blocks = (dkLen + 31) / 32;
        using (HMACSHA256 hmac = new HMACSHA256(password))
        {
            for (int b = 1; b <= blocks; b++)
            {
                byte[] sb = new byte[salt.Length + 4];
                Buffer.BlockCopy(salt, 0, sb, 0, salt.Length);
                sb[salt.Length] = (byte)(b >> 24);
                sb[salt.Length + 1] = (byte)(b >> 16);
                sb[salt.Length + 2] = (byte)(b >> 8);
                sb[salt.Length + 3] = (byte)b;
                byte[] u = hmac.ComputeHash(sb);
                byte[] t = (byte[])u.Clone();
                for (int i = 1; i < iterations; i++)
                {
                    u = hmac.ComputeHash(u);
                    for (int j = 0; j < t.Length; j++) t[j] ^= u[j];
                }
                int off = (b - 1) * 32;
                int len = Math.Min(32, dkLen - off);
                Buffer.BlockCopy(t, 0, result, off, len);
            }
        }
        return result;
    }
}
'@
if (-not ('DapCrypto' -as [type])) { Add-Type -TypeDefinition $script:CsSource -Language CSharp }

# ---------- basic helpers ----------
function Get-UtcNow { [DateTime]::UtcNow }
function Get-Kst { [DateTime]::UtcNow.AddHours(9) }

function New-RandomBytes([int]$n) {
    $b = New-Object 'byte[]' $n
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    $rng.GetBytes($b)
    $rng.Dispose()
    return ,$b
}

function Test-SameText([string]$a, [string]$b) {
    if ($null -eq $a -or $null -eq $b -or $a.Length -ne $b.Length) { return $false }
    $diff = 0
    for ($i = 0; $i -lt $a.Length; $i++) { $diff = $diff -bor ([int][char]$a[$i] -bxor [int][char]$b[$i]) }
    return ($diff -eq 0)
}

function Fail-Http([int]$code, [string]$err) { throw "HTTP:$($code):$err" }

function Initialize-Dirs {
    foreach ($d in @($script:Base, (Split-Path -Parent $script:LogPath))) {
        New-Item -ItemType Directory -Force -Path $d | Out-Null
    }
}

function Write-Log([string]$msg) {
    try {
        if ((Test-Path -LiteralPath $script:LogPath) -and ((Get-Item -LiteralPath $script:LogPath).Length -gt 1MB)) {
            Move-Item -LiteralPath $script:LogPath -Destination ($script:LogPath + '.old') -Force
        }
        $line = (Get-Kst).ToString('yyyy-MM-dd HH:mm:ss') + ' ' + $msg + "`r`n"
        [IO.File]::AppendAllText($script:LogPath, $line, $script:Utf8)
    } catch { }
}

function Write-Durable([string]$path, [string]$text) {
    $dir = Split-Path -Parent $path
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $tmp = $path + '.tmp'
    $bytes = $script:Utf8.GetBytes($text)
    $fs = [IO.File]::Open($tmp, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try { $fs.Write($bytes, 0, $bytes.Length); $fs.Flush($true) } finally { $fs.Dispose() }
    if (Test-Path -LiteralPath $path) {
        # PowerShell 5.1은 null string을 빈 문자열로 바인딩할 수 있으므로 실제 백업 경로 사용
        $bak = $path + '.bak'
        [IO.File]::Replace($tmp, $path, $bak, $true)
        try { [IO.File]::Delete($bak) } catch { }
    } else { [IO.File]::Move($tmp, $path) }
}

function Read-JsonFile([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    try {
        $t = [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8)
        if (-not $t.Trim()) { return $null }
        return (ConvertFrom-Json -InputObject $t)
    } catch {
        Write-Log ('설정 파일 읽기 실패: ' + (Split-Path -Leaf $path))
        return $null
    }
}

# DPAPI (CurrentUser): secrets never leave this Windows account
function Protect-Text([string]$text) {
    $b = $script:Utf8.GetBytes($text)
    $p = [Security.Cryptography.ProtectedData]::Protect($b, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
    return [Convert]::ToBase64String($p)
}
function Unprotect-Text([string]$b64) {
    $p = [Convert]::FromBase64String($b64)
    $b = [Security.Cryptography.ProtectedData]::Unprotect($p, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
    return [Text.Encoding]::UTF8.GetString($b)
}
function Save-Secret([string]$path, [string]$text) { Write-Durable $path (Protect-Text $text) }
function Load-Secret([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    try { return (Unprotect-Text ([IO.File]::ReadAllText($path).Trim())) } catch { Write-Log '보관 파일을 풀 수 없음 (다른 Windows 계정이거나 손상)'; return $null }
}

# ---------- encrypted dashboard documents (PBKDF2-SHA256 100000 + AES-256-GCM, WebCrypto layout) ----------
function Open-EncDoc([string]$text, [string]$pass) {
    $o = ConvertFrom-Json -InputObject $text
    if (-not $o.salt -or -not $o.iv -or -not $o.ct) { throw 'BAD_FORMAT' }
    if ($o.kdf -and ([string]$o.kdf -notmatch '(?i)pbkdf2.*100000')) { throw 'BAD_FORMAT' }
    $salt = [Convert]::FromBase64String([string]$o.salt)
    $iv = [Convert]::FromBase64String([string]$o.iv)
    $ct = [Convert]::FromBase64String([string]$o.ct)
    if ($ct.Length -lt 17 -or $iv.Length -eq 0) { throw 'BAD_FORMAT' }
    $body = New-Object 'byte[]' ($ct.Length - 16)
    [Array]::Copy($ct, 0, $body, 0, $body.Length)
    $tag = New-Object 'byte[]' 16
    [Array]::Copy($ct, $body.Length, $tag, 0, 16)
    $key = [DapCrypto]::Pbkdf2Sha256($script:Utf8.GetBytes($pass), $salt, 100000, 32)
    try { $plain = [DapCrypto]::AesGcmDecrypt($key, $iv, $body, $tag) } catch { throw 'DECRYPT_FAILED' }
    try { return (ConvertFrom-Json -InputObject ([Text.Encoding]::UTF8.GetString($plain))) } catch { throw 'BAD_FORMAT' }
}

function Seal-EncDoc([string]$json, [string]$pass) {
    $salt = New-RandomBytes 16
    $iv = New-RandomBytes 12
    $key = [DapCrypto]::Pbkdf2Sha256($script:Utf8.GetBytes($pass), $salt, 100000, 32)
    $tag = New-Object 'byte[]' 16
    $ct = [DapCrypto]::AesGcmEncrypt($key, $iv, $script:Utf8.GetBytes($json), $tag)
    $all = New-Object 'byte[]' ($ct.Length + 16)
    [Array]::Copy($ct, 0, $all, 0, $ct.Length)
    [Array]::Copy($tag, 0, $all, $ct.Length, 16)
    return (ConvertTo-Json -InputObject ([ordered]@{ v = 1; kdf = 'PBKDF2-SHA256-100000'; salt = [Convert]::ToBase64String($salt); iv = [Convert]::ToBase64String($iv); ct = [Convert]::ToBase64String($all) }) -Compress)
}

function Get-Remote([string]$url) {
    # 인터넷이 끊겼을 때 예약 10개가 각각 기다려 설정창까지 막히지 않게 한다.
    if (((Get-UtcNow) - $script:RemoteErrorAt).TotalSeconds -lt 30) { throw 'NETWORK_BACKOFF' }
    $resp = $null
    $sr = $null
    try {
        $req = [Net.HttpWebRequest]::Create($url)
        $req.Timeout = 10000
        $req.ReadWriteTimeout = 10000
        $req.UserAgent = 'DrawbreadAutoPrint/1.0'
        $req.Headers.Add('Cache-Control', 'no-cache')
        $resp = $req.GetResponse()
        $sr = New-Object IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8)
        return $sr.ReadToEnd()
    } catch {
        $script:RemoteErrorAt = Get-UtcNow
        throw
    } finally {
        if ($sr) { $sr.Dispose() }
        if ($resp) { $resp.Close() }
    }
}

function Get-AdminPass {
    $p = Load-Secret $script:KeyPath
    if (-not $p) { throw 'NO_KEY' }
    return $p
}

function Get-DashIndex {
    if ($script:IdxCache -and (((Get-UtcNow) - $script:IdxAt).TotalSeconds -lt 60)) { return $script:IdxCache }
    $pass = Get-AdminPass
    $txt = Get-Remote ($script:RemoteBase + 'dash.enc.json?t=' + [DateTime]::UtcNow.Ticks)
    $idx = Open-EncDoc $txt $pass
    $script:IdxCache = $idx
    $script:IdxAt = Get-UtcNow
    return $idx
}

# ---------- printers ----------
function Get-PrinterList {
    $all = @([Drawing.Printing.PrinterSettings]::InstalledPrinters)
    return @($all | Where-Object { $_ -notmatch 'PDF|XPS|OneNote|Fax|Send To|Document Writer' })
}

function Get-DefaultPrinterName {
    $ps = New-Object Drawing.Printing.PrinterSettings
    $n = [string]$ps.PrinterName
    if (@(Get-PrinterList) -contains $n) { return $n }
    return ''
}

# revision may be a number or an ISO-like text: compare safely as text when not numeric
function Get-RevKey($v) {
    $d = 0.0
    if ([double]::TryParse([string]$v, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) { return ('n' + $d.ToString('0000000000.000', [Globalization.CultureInfo]::InvariantCulture)) }
    return ('s' + [string]$v)
}

# ---------- source selection (pure logic) ----------
function Get-SourceChoice($idx, [string]$kind, [string]$mode, [string]$today, [string]$yest) {
    $target = if ($mode -eq 'yesterday') { $yest } else { $today }
    if ($kind -eq 'delivery') {
        $ds = $idx.deliverySchedule
        $entries = @($ds.entries | Where-Object { $_ })
        if ($mode -eq 'latest') {
            $cand = @($entries | Where-Object { $_.weekStart -and $_.weekEnd -and ([string]$_.weekStart -le $today) -and ($today -le [string]$_.weekEnd) })
        } else {
            $cand = @($entries | Where-Object { [string]$_.scheduleDate -eq $target })
        }
        if ($cand.Count -gt 0) {
            $best = @($cand | Sort-Object -Property @{Expression = { [string]$_.scheduleDate }; Descending = $true }, @{Expression = { Get-RevKey $_.revision }; Descending = $true })[0]
            return [pscustomobject]@{ found = $true; date = [string]$best.scheduleDate; file = [string]$best.file; inline = $false }
        }
        if ($ds -and $ds.image) {
            if ($mode -eq 'latest') {
                $inlineOk = ($ds.weekStart -and $ds.weekEnd -and ([string]$ds.weekStart -le $today) -and ($today -le [string]$ds.weekEnd))
            } else {
                $inlineOk = ([string]$ds.scheduleDate -eq $target)
            }
            if ($inlineOk) { return [pscustomobject]@{ found = $true; date = [string]$ds.scheduleDate; file = ''; inline = $true } }
        }
        return [pscustomobject]@{ found = $false; date = ''; file = ''; inline = $false }
    }
    $entries = @($idx.productionJournal.entries | Where-Object { $_ })
    if ($mode -eq 'latest') {
        $cand = @($entries | Where-Object { @($today, $yest) -contains [string]$_.date })
    } else {
        $cand = @($entries | Where-Object { [string]$_.date -eq $target })
    }
    if ($cand.Count -gt 0) {
        $best = @($cand | Sort-Object -Property @{Expression = { [string]$_.date }; Descending = $true }, @{Expression = { Get-RevKey $_.revision }; Descending = $true })[0]
        return [pscustomobject]@{ found = $true; date = [string]$best.date; file = [string]$best.file; inline = $false }
    }
    return [pscustomobject]@{ found = $false; date = ''; file = ''; inline = $false }
}

function Get-SourceDoc($idx, $choice, [string]$kind, [string]$mode, [string]$today) {
    if ($choice.inline) {
        $doc = $idx.deliverySchedule
    } else {
        if ([string]$choice.file -notmatch ('^' + $kind + '_20\d{6}\.enc\.json$')) { throw 'BAD_FILE_NAME' }
        $txt = Get-Remote ($script:RemoteBase + [string]$choice.file)
        $doc = Open-EncDoc $txt (Get-AdminPass)
    }
    if ($kind -eq 'delivery') {
        if ([string]$doc.scheduleDate -ne $choice.date) { throw 'DOC_DATE_MISMATCH' }
        if ($mode -eq 'latest' -and -not (([string]$doc.weekStart -le $today) -and ($today -le [string]$doc.weekEnd))) { throw 'DOC_WEEK_OUT' }
        $imgs = @([string]$doc.image)
    } else {
        if ([string]$doc.date -ne $choice.date) { throw 'DOC_DATE_MISMATCH' }
        $imgs = @($doc.images | Where-Object { $_ } | ForEach-Object { [string]$_ })
    }
    if ($imgs.Count -eq 0) { throw 'DOC_NO_IMAGE' }
    if ($imgs.Count -gt 20) { throw 'DOC_TOO_MANY_PAGES' }
    $totalBytes = 0
    foreach ($u in $imgs) {
        if ($u -notmatch '^data:image/(png|jpeg|gif|bmp);base64,[A-Za-z0-9+/=\r\n]+$') { throw 'DOC_BAD_IMAGE' }
        $approx = [int64](($u.Length - $u.IndexOf(',') - 1) * 3 / 4)
        if ($approx -gt 20MB) { throw 'DOC_IMAGE_TOO_BIG' }
        $totalBytes += $approx
        if ($totalBytes -gt 40MB) { throw 'DOC_TOTAL_TOO_BIG' }
    }
    return [pscustomobject]@{ images = $imgs; delivery = ($kind -eq 'delivery') }
}

function ConvertTo-Bitmap([string]$du) {
    $b64 = $du.Substring($du.IndexOf(',') + 1)
    $bytes = [Convert]::FromBase64String($b64)
    $ms = New-Object IO.MemoryStream -ArgumentList (,$bytes)
    try {
        $img = [Drawing.Image]::FromStream($ms)
        try { return (New-Object Drawing.Bitmap -ArgumentList $img) } finally { $img.Dispose() }
    } finally { $ms.Dispose() }
}

# ---------- print history (idempotency) ----------
function Load-Records {
    $r = Read-JsonFile $script:HistPath
    $script:Records = @(@($r) | Where-Object { $_ })
}
function Save-Records {
    Write-Durable $script:HistPath (ConvertTo-Json -InputObject @($script:Records) -Depth 5)
}
function Add-Record($rec) {
    $script:Records = @(@($script:Records) + @($rec))
    if ($script:Records.Count -gt 300) { $script:Records = @($script:Records | Select-Object -Last 300) }
    Save-Records
}
function Find-Record([string]$key) {
    return (@($script:Records | Where-Object { $_.key -eq $key }) | Select-Object -First 1)
}
function Set-RecordStatus([string]$key, [string]$status, [string]$msg) {
    foreach ($r in @($script:Records)) {
        if ($r.key -eq $key) { $r.status = $status; $r.message = $msg }
    }
    Save-Records
}
function Short-Text([string]$m) {
    if ($null -eq $m) { return '' }
    if ($m.Length -gt 200) { return $m.Substring(0, 200) }
    return $m
}

# ---------- printing ----------
function Invoke-PrintJob($bitmaps, [bool]$landscape, [int]$copies, [string]$printer) {
    if ($script:DryRunGlobal) { throw 'DRY_RUN_NO_PRINT' }
    $pd = New-Object Drawing.Printing.PrintDocument
    $pd.PrinterSettings.PrinterName = $printer
    if (-not $pd.PrinterSettings.IsValid) { throw 'PRINTER_INVALID' }
    $pd.PrinterSettings.Duplex = [Drawing.Printing.Duplex]::Simplex
    $pd.PrinterSettings.Copies = [short]$copies
    $pd.PrinterSettings.Collate = $true
    $a4 = $null
    foreach ($ps in @($pd.PrinterSettings.PaperSizes)) { if ($ps.Kind -eq [Drawing.Printing.PaperKind]::A4) { $a4 = $ps } }
    if (-not $a4) { $a4 = New-Object Drawing.Printing.PaperSize -ArgumentList 'A4', 827, 1169; $a4.RawKind = 9 }
    $pd.DefaultPageSettings.PaperSize = $a4
    $pd.DefaultPageSettings.Landscape = $landscape
    $pd.DefaultPageSettings.Margins = New-Object Drawing.Printing.Margins -ArgumentList 32, 32, 32, 32
    $pd.PrintController = New-Object Drawing.Printing.StandardPrintController
    $pd.DocumentName = 'DrawbreadAutoPrint'
    $state = @{ i = 0; bmps = $bitmaps }
    $pd.add_PrintPage({
        param($sender, $e)
        $script:PrintStarted = $true
        $e.Graphics.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $img = $state.bmps[$state.i]
        $area = $e.MarginBounds
        $sc = [Math]::Min($area.Width / $img.Width, $area.Height / $img.Height)
        $w = [int]($img.Width * $sc)
        $h = [int]($img.Height * $sc)
        $x = [int]($area.X + ($area.Width - $w) / 2)
        $y = [int]($area.Y + ($area.Height - $h) / 2)
        $e.Graphics.DrawImage($img, (New-Object Drawing.Rectangle -ArgumentList $x, $y, $w, $h))
        $state.i = $state.i + 1
        $e.HasMorePages = ($state.i -lt $state.bmps.Count)
    })
    try { $pd.Print() } finally { $pd.Dispose() }
}

# ---------- scheduler ----------
function Invoke-Schedule($s, [bool]$dry, [bool]$readiness) {
    $now = Get-Kst
    $today = $now.ToString('yyyy-MM-dd')
    $yest = $now.AddDays(-1).ToString('yyyy-MM-dd')
    $key = "$today|$($s.id)|$($s.time)"
    $r = [pscustomobject]@{ id = [string]$s.id; key = $key; status = ''; detail = ''; date = ''; file = '' }
    $dryAll = $dry -or $script:DryRunGlobal

    if (-not $readiness) {
        if (-not $s.enabled) { $r.status = 'disabled'; return $r }
        if ($script:Paused) { $r.status = 'paused'; return $r }
        if (@($s.days) -notcontains [int]$now.DayOfWeek) { $r.status = 'not_today'; return $r }
        $hh = [int]$s.time.Substring(0, 2)
        $mm = [int]$s.time.Substring(3, 2)
        $schedAt = New-Object DateTime -ArgumentList $now.Year, $now.Month, $now.Day, $hh, $mm, 0
        $d = ($now - $schedAt).TotalMinutes
        if ($d -lt 0) { $r.status = 'waiting_time'; return $r }
        $rec = Find-Record $key
        if ($rec) { $r.status = 'done'; $r.detail = [string]$rec.status; return $r }
        if ($d -gt $script:GraceMinutes) {
            $r.status = 'late'
            $r.detail = [string]$script:LastReason[$key]
            if (-not $dryAll) {
                Add-Record ([pscustomobject]@{ at = $now.ToString('yyyy-MM-dd HH:mm:ss'); key = $key; id = [string]$s.id; kind = [string]$s.kind; date = $today; time = [string]$s.time; printer = [string]$s.printer; copies = [int]$s.copies; status = 'skipped'; message = ('30분 안에 인쇄 조건을 못 맞춤' + $(if ($r.detail) { ': ' + $r.detail } else { '' })) })
                Write-Log ('예약 건너뜀: ' + [string]$s.id)
            }
            return $r
        }
    }

    try {
        $idx = Get-DashIndex
    } catch {
        $m = [string]$_.Exception.Message
        if ($m -match 'NO_KEY') { $st = 'no_key'; $dt = '관리자 key가 아직 없음' }
        elseif ($m -match 'DECRYPT_FAILED') { $st = 'admin_key_failed'; $dt = '관리자 key가 맞지 않음 (대시보드에서 다시 입력)' }
        else { $st = 'waiting_data'; $dt = '대시보드 자료를 받지 못함 (재확인)' }
        $r.status = $st; $r.detail = $dt
        $script:LastReason[$key] = $dt
        $nk = "$key|$st"
        if (-not $dryAll -and $st -ne 'waiting_data' -and -not $script:Notice[$nk]) {
            $script:Notice[$nk] = $true
            Add-Record ([pscustomobject]@{ at = $now.ToString('yyyy-MM-dd HH:mm:ss'); key = $null; id = [string]$s.id; kind = [string]$s.kind; date = $today; time = [string]$s.time; printer = ''; copies = 0; status = $st; message = $dt })
        }
        return $r
    }

    $choice = Get-SourceChoice $idx ([string]$s.kind) ([string]$s.dateMode) $today $yest
    $r.date = [string]$choice.date
    $r.file = [string]$choice.file
    if (-not $choice.found) {
        $r.status = 'waiting_data'; $r.detail = '해당 날짜 자료 없음'
        $script:LastReason[$key] = $r.detail
        return $r
    }
    try {
        $src = Get-SourceDoc $idx $choice ([string]$s.kind) ([string]$s.dateMode) $today
    } catch {
        $r.status = 'waiting_data'
        $r.detail = '자료 확인 실패: ' + [string]$_.Exception.Message
        $script:LastReason[$key] = '자료 확인 실패(날짜·형식)'
        return $r
    }
    if (@(Get-PrinterList) -notcontains [string]$s.printer) {
        $r.status = 'waiting_printer'; $r.detail = '프린터가 연결되어 있지 않음'
        $script:LastReason[$key] = $r.detail
        return $r
    }
    if ($readiness -or $dryAll) {
        $r.status = 'ready'
        $r.detail = ('자료 ' + $src.images.Count + '장 준비됨')
        return $r
    }

    # durable claim before printing: never print the same key twice
    Add-Record ([pscustomobject]@{ at = $now.ToString('yyyy-MM-dd HH:mm:ss'); key = $key; id = [string]$s.id; kind = [string]$s.kind; date = $choice.date; time = [string]$s.time; printer = [string]$s.printer; copies = [int]$s.copies; status = 'printing'; message = '' })
    $bitmaps = @()
    $final = 'failed'
    $msg = ''
    $script:PrintStarted = $false
    try {
        foreach ($u in $src.images) { $bitmaps += (ConvertTo-Bitmap $u) }
        $landscape = $true
        if (-not $src.delivery) { $landscape = ($bitmaps[0].Width -gt $bitmaps[0].Height) }
        Invoke-PrintJob $bitmaps $landscape ([int]$s.copies) ([string]$s.printer)
        $final = 'delivered'
        $msg = '프린터 전달 (실물 출력 완료는 확인하지 않음)'
    } catch {
        if ($script:PrintStarted) { $final = 'unknown' } else { $final = 'failed' }
        $msg = Short-Text ([string]$_.Exception.Message)
    } finally {
        foreach ($b in $bitmaps) { $b.Dispose() }
    }
    Set-RecordStatus $key $final $msg
    Write-Log ('예약 처리: ' + [string]$s.id + ' -> ' + $final)
    $r.status = $final
    $r.detail = $msg
    return $r
}

function Invoke-SchedulerTick {
    if (-not $script:Cfg -or $script:Paused) { return }
    foreach ($s in @($script:Cfg.schedules)) {
        if ($s) { [void](Invoke-Schedule $s $false $false) }
    }
}

# ---------- config ----------
function Load-Config {
    $c = Read-JsonFile $script:CfgPath
    if (-not $c) { $c = [pscustomobject]@{ schemaVersion = 1; paused = $false; schedules = @() } }
    $script:Cfg = $c
    $script:Paused = [bool]$c.paused
}

function Save-Config($schedules, $paused) {
    $obj = [pscustomobject]@{ schemaVersion = 1; paused = [bool]$paused; schedules = @($schedules) }
    Write-Durable $script:CfgPath (ConvertTo-Json -InputObject $obj -Depth 6)
    $script:Cfg = $obj
    $script:Paused = [bool]$paused
}

# integers only: 1.5 is refused instead of silently rounded
function Get-StrictInt($v, [string]$err) {
    if ($v -is [int] -or $v -is [long]) { return [int]$v }
    if ($v -is [double] -and [Math]::Floor($v) -eq $v) { return [int]$v }
    Fail-Http 400 $err
}

function Test-Schedules($raw, [string[]]$printers) {
    $arr = @(@($raw) | Where-Object { $_ })
    if ($arr.Count -gt $script:MaxSchedules) { Fail-Http 400 'too_many_schedules' }
    $out = @()
    $ids = @{}
    for ($i = 0; $i -lt $arr.Count; $i++) {
        $s = $arr[$i]
        $id = [string]$s.id
        if (-not $id) { $id = 's' + ($i + 1) }
        if ($id -notmatch '^[A-Za-z0-9_-]{1,40}$') { Fail-Http 400 'bad_id' }
        if ($ids.ContainsKey($id)) { Fail-Http 400 'dup_id' }
        $ids[$id] = $true
        $kind = [string]$s.kind
        if (@('delivery', 'production') -notcontains $kind) { Fail-Http 400 'bad_kind' }
        $time = [string]$s.time
        if ($time -notmatch '^([01]\d|2[0-3]):[0-5]\d$') { Fail-Http 400 'bad_time' }
        $days = @(@($s.days | Where-Object { $_ -ne $null }) | ForEach-Object { Get-StrictInt $_ 'bad_days' } | Sort-Object -Unique)
        if ($days.Count -lt 1 -or @($days | Where-Object { $_ -lt 0 -or $_ -gt 6 }).Count -gt 0) { Fail-Http 400 'bad_days' }
        $printer = [string]$s.printer
        if (@($printers) -notcontains $printer) { Fail-Http 400 'printer_not_found' }
        $copies = 1
        if ($null -ne $s.copies) { $copies = Get-StrictInt $s.copies 'bad_copies' }
        if ($copies -lt 1 -or $copies -gt 5) { Fail-Http 400 'bad_copies' }
        $mode = [string]$s.dateMode
        if (@('today', 'yesterday', 'latest') -notcontains $mode) { Fail-Http 400 'bad_date_mode' }
        $en = $true
        if ($null -ne $s.enabled) { $en = [bool]$s.enabled }
        $out += [pscustomobject]@{ id = $id; kind = $kind; time = $time; days = $days; printer = $printer; copies = $copies; dateMode = $mode; enabled = $en }
    }
    return ,$out
}

# schedules added or re-timed after their time today are skipped for today (never printed in a burst)
function Mark-PastSchedules($oldList, $newList) {
    $now = Get-Kst
    $today = $now.ToString('yyyy-MM-dd')
    foreach ($s in @($newList)) {
        if (-not $s.enabled) { continue }
        $same = @($oldList | Where-Object { $_ -and $_.id -eq $s.id -and $_.time -eq $s.time })
        if ($same.Count -gt 0) { continue }
        if (@($s.days) -notcontains [int]$now.DayOfWeek) { continue }
        $hh = [int]$s.time.Substring(0, 2)
        $mm = [int]$s.time.Substring(3, 2)
        $schedAt = New-Object DateTime -ArgumentList $now.Year, $now.Month, $now.Day, $hh, $mm, 0
        if (($now - $schedAt).TotalMinutes -lt 0) { continue }
        $key = "$today|$($s.id)|$($s.time)"
        if (Find-Record $key) { continue }
        Add-Record ([pscustomobject]@{ at = $now.ToString('yyyy-MM-dd HH:mm:ss'); key = $key; id = [string]$s.id; kind = [string]$s.kind; date = $today; time = [string]$s.time; printer = [string]$s.printer; copies = [int]$s.copies; status = 'skipped'; message = '설정 저장 시점이 예약 시각을 지나서 오늘은 건너뜀' })
        Write-Log ('설정 저장 시 지난 예약 건너뜀: ' + [string]$s.id)
    }
}

# ---------- pairing ----------
function Show-PairPopup([string]$code) {
    if ($NoPopup) { return }
    $txt = "대시보드 자동 인쇄 연결 코드: $code`n`n10분 안에 대시보드 설정 화면의 연결 칸에 입력하세요.`n5번 틀리면 새 코드가 다시 뜹니다."
    $ps1 = @'
Add-Type -AssemblyName System.Windows.Forms
$f = New-Object System.Windows.Forms.Form
$f.TopMost = $true; $f.ShowInTaskbar = $false; $f.Opacity = 0; $f.StartPosition = 'CenterScreen'
$f.Show()
[void][System.Windows.Forms.MessageBox]::Show($f, __TEXT__, '조조 자동 인쇄 연결', 'OK', 'Information')
$f.Dispose()
'@
    $ps1 = $ps1.Replace('__TEXT__', "'" + $txt.Replace("'", "''") + "'")
    $enc = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($ps1))
    $null = Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-WindowStyle', 'Hidden', '-EncodedCommand', $enc) -PassThru
}

function New-PairingCode {
    if ($PairCode -match '^\d{6}$') {
        $code = $PairCode
    } else {
        $b = New-RandomBytes 4
        $code = ([BitConverter]::ToUInt32($b, 0) % 1000000).ToString('000000')
    }
    $script:PendingCode = $code
    $script:PairExpires = (Get-UtcNow).AddMinutes(10)
    $script:PairFails = 0
    Write-Log '연결 코드 발급 (10분 유효)'
    Show-PairPopup $code
}

# ---------- HTTP (minimal, loopback only) ----------
function Read-HttpRequest($client) {
    $ns = $client.GetStream()
    $ms = New-Object IO.MemoryStream
    $buf = New-Object 'byte[]' 4096
    $deadline = (Get-UtcNow).AddSeconds(3)
    $hEnd = -1
    $clen = 0
    while ($true) {
        if ((Get-UtcNow) -gt $deadline) { return $null }
        $n = $ns.Read($buf, 0, $buf.Length)
        if ($n -le 0) { break }
        $ms.Write($buf, 0, $n)
        if ($ms.Length -gt ($script:MaxBody + 8192)) { return @{ error = 413 } }
        if ($hEnd -lt 0) {
            $arr = $ms.GetBuffer()
            $len = [int]$ms.Length
            for ($i = 0; $i -le $len - 4; $i++) {
                if ($arr[$i] -eq 13 -and $arr[$i + 1] -eq 10 -and $arr[$i + 2] -eq 13 -and $arr[$i + 3] -eq 10) { $hEnd = $i; break }
            }
            if ($hEnd -ge 0) {
                $head0 = $script:Utf8.GetString($arr, 0, $hEnd)
                $cm = [regex]::Match($head0, '(?im)^content-length:\s*(\d+)')
                if ($cm.Success) { $clen = [int64]$cm.Groups[1].Value }
                if ($clen -gt $script:MaxBody) { return @{ error = 413 } }
            }
        }
        if ($hEnd -ge 0 -and $ms.Length -ge ($hEnd + 4 + $clen)) { break }
    }
    if ($hEnd -lt 0) { return $null }
    $all = $ms.ToArray()
    $head = $script:Utf8.GetString($all, 0, $hEnd)
    $lines = $head -split "`r`n"
    $parts = $lines[0] -split ' '
    $headers = @{}
    for ($i = 1; $i -lt $lines.Count; $i++) {
        $k = $lines[$i].IndexOf(':')
        if ($k -gt 0) { $headers[$lines[$i].Substring(0, $k).Trim().ToLower()] = $lines[$i].Substring($k + 1).Trim() }
    }
    $body = $script:Utf8.GetString($all, $hEnd + 4, [int]$clen)
    return @{ method = $parts[0]; path = (($parts[1]) -split '\?')[0]; headers = $headers; body = $body }
}

function Send-Reply($ns, [int]$code, $obj, [bool]$cors, [bool]$preflight) {
    $reasons = @{ 200 = 'OK'; 204 = 'No Content'; 400 = 'Bad Request'; 401 = 'Unauthorized'; 403 = 'Forbidden'; 404 = 'Not Found'; 409 = 'Conflict'; 410 = 'Gone'; 413 = 'Payload Too Large'; 415 = 'Unsupported Media Type'; 423 = 'Locked'; 500 = 'Internal Server Error'; 503 = 'Service Unavailable' }
    $body = ''
    if ($null -ne $obj) { $body = ConvertTo-Json -InputObject $obj -Depth 6 -Compress }
    $bytes = $script:Utf8.GetBytes($body)
    $h = "HTTP/1.1 $code $($reasons[$code])`r`n"
    $h += "Content-Type: application/json; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nConnection: close`r`n"
    if ($cors) { $h += "Access-Control-Allow-Origin: $($script:AllowedOrigin)`r`nVary: Origin`r`nAccess-Control-Allow-Private-Network: true`r`n" }
    if ($preflight) { $h += "Access-Control-Allow-Methods: GET, POST, OPTIONS`r`nAccess-Control-Allow-Headers: Content-Type, Authorization`r`nAccess-Control-Max-Age: 600`r`n" }
    $h += "`r`n"
    $hb = [Text.Encoding]::ASCII.GetBytes($h)
    $ns.Write($hb, 0, $hb.Length)
    if ($bytes.Length -gt 0) { $ns.Write($bytes, 0, $bytes.Length) }
    $ns.Flush()
}

function Get-JsonBody($req) {
    $ct = [string]$req.headers['content-type']
    if ($ct -notmatch '^(application/json|text/plain)') { Fail-Http 415 'unsupported_type' }
    if (-not $req.body.Trim()) { return [pscustomobject]@{} }
    try { return (ConvertFrom-Json -InputObject $req.body) } catch { Fail-Http 400 'bad_json' }
}

function Assert-Auth($req) {
    if (-not $script:Token) { Fail-Http 401 'not_paired' }
    $h = [string]$req.headers['authorization']
    if (-not $h.StartsWith('Bearer ')) { Fail-Http 401 'unauthorized' }
    if (-not (Test-SameText ($h.Substring(7).Trim()) $script:Token)) { Fail-Http 401 'unauthorized' }
}

function Get-RecentHistory {
    $h = @($script:Records)
    $out = @()
    $start = [Math]::Max(0, $h.Count - 20)
    for ($i = $h.Count - 1; $i -ge $start; $i--) { $out += $h[$i] }
    return $out
}

function Handle-Client($client) {
    $client.ReceiveTimeout = 2000
    $client.SendTimeout = 5000
    $ns = $client.GetStream()
    $req = Read-HttpRequest $client
    if ($null -eq $req) { return }
    if ($req.error) { Send-Reply $ns $req.error @{ ok = $false; error = 'too_large' } $false $false; return }
    $origin = [string]$req.headers['origin']
    $hostHdr = [string]$req.headers['host']
    if ($hostHdr -ne "127.0.0.1:$Port") { Send-Reply $ns 403 @{ ok = $false; error = 'bad_host' } $false $false; return }
    if ($origin -ne $script:AllowedOrigin) { Send-Reply $ns 403 @{ ok = $false; error = 'origin_not_allowed' } $false $false; return }
    if ($req.method -eq 'OPTIONS') { Send-Reply $ns 204 $null $true $true; return }
    $route = "$($req.method) $($req.path)"
    try {
        if ($route -eq 'GET /status') {
            Send-Reply $ns 200 @{ ok = $true; version = $script:Version; paired = [bool]$script:Token; pc = $env:COMPUTERNAME } $true $false
        }
        elseif ($route -eq 'GET /state') {
            Assert-Auth $req
            $printers = @(Get-PrinterList)
            Send-Reply $ns 200 @{ ok = $true; pc = $env:COMPUTERNAME; printers = $printers; defaultPrinter = (Get-DefaultPrinterName); schedules = @($script:Cfg.schedules); history = @(Get-RecentHistory); paused = [bool]$script:Paused } $true $false
        }
        elseif ($route -eq 'POST /pair') {
            $b = Get-JsonBody $req
            if ($script:Token) { Fail-Http 409 'already_paired' }
            if ((Get-UtcNow) -gt $script:PairExpires) { New-PairingCode; Fail-Http 410 'code_expired' }
            $code = [string]$b.code
            if ($code -notmatch '^\d{6}$') { Fail-Http 400 'bad_code_format' }
            if (Test-SameText $code $script:PendingCode) {
                $tok = [Convert]::ToBase64String((New-RandomBytes 32))
                Save-Secret $script:TokPath $tok
                $script:Token = $tok
                $script:PendingCode = ''
                $script:PairExpires = [DateTime]::MinValue
                Write-Log '대시보드와 연결됨'
                Send-Reply $ns 200 @{ ok = $true; token = $tok; pc = $env:COMPUTERNAME } $true $false
            } else {
                $script:PairFails = $script:PairFails + 1
                Write-Log '연결 코드 불일치'
                if ($script:PairFails -ge $script:MaxPairFails) {
                    New-PairingCode
                    Send-Reply $ns 423 @{ ok = $false; error = 'locked_new_code_shown' } $true $false
                } else {
                    Send-Reply $ns 401 @{ ok = $false; error = 'bad_code'; left = ($script:MaxPairFails - $script:PairFails) } $true $false
                }
            }
        }
        elseif ($route -eq 'POST /config') {
            Assert-Auth $req
            $b = Get-JsonBody $req
            $printers = @(Get-PrinterList)
            $names = @($b.PSObject.Properties.Name)
            $schedRaw = $script:Cfg.schedules
            if ($names -contains 'schedules') { $schedRaw = $b.schedules }
            $scheds = Test-Schedules $schedRaw $printers
            if (($names -contains 'key') -and $b.key) {
                $cand = [string]$b.key
                try {
                    $txt = Get-Remote ($script:RemoteBase + 'dash.enc.json?t=' + [DateTime]::UtcNow.Ticks)
                    [void](Open-EncDoc $txt $cand)
                } catch {
                    $em = [string]$_.Exception.Message
                    if ($em -match 'DECRYPT_FAILED|BAD_FORMAT') { Fail-Http 400 'key_invalid' }
                    Fail-Http 503 'network'
                }
                Save-Secret $script:KeyPath $cand
                $script:IdxCache = $null
                Write-Log '관리자 key 저장됨 (값은 기록하지 않음)'
            }
            $paused = [bool]$script:Paused
            if ($names -contains 'paused') { $paused = [bool]$b.paused }
            $oldScheds = @($script:Cfg.schedules)
            Save-Config $scheds $paused
            Mark-PastSchedules $oldScheds $scheds
            Write-Log ('설정 저장: 예약 ' + $scheds.Count + '개')
            Send-Reply $ns 200 @{ ok = $true } $true $false
        }
        elseif ($route -eq 'POST /pause') {
            Assert-Auth $req
            $b = Get-JsonBody $req
            if ($b.paused -isnot [bool]) { Fail-Http 400 'bad_paused' }
            Save-Config $script:Cfg.schedules $b.paused
            Write-Log ('일시정지 ' + $(if ($b.paused) { '켬' } else { '끔' }))
            Send-Reply $ns 200 @{ ok = $true; paused = [bool]$script:Paused } $true $false
        }
        elseif ($route -eq 'POST /unpair') {
            Assert-Auth $req
            # 삭제 권한 문제가 있어도 예약은 먼저 영구 정지한다.
            Save-Config $script:Cfg.schedules $true
            $script:IdxCache = $null
            if (Test-Path -LiteralPath $script:KeyPath) { Remove-Item -LiteralPath $script:KeyPath -Force }
            if (Test-Path -LiteralPath $script:TokPath) { Remove-Item -LiteralPath $script:TokPath -Force }
            $script:Token = $null
            $script:IdxCache = $null
            Save-Config $script:Cfg.schedules $true
            Write-Log '연결 해제 (안전 정지, 관리자 key 삭제)'
            New-PairingCode
            Send-Reply $ns 200 @{ ok = $true; paused = $true } $true $false
        }
        elseif ($route -eq 'POST /test') {
            Assert-Auth $req
            $b = Get-JsonBody $req
            if ($b.dryRun -ne $true) { Fail-Http 403 'dry_run_required' }
            $s = (@($script:Cfg.schedules | Where-Object { $_.id -eq [string]$b.id }) | Select-Object -First 1)
            if (-not $s) { Fail-Http 404 'schedule_not_found' }
            $r = Invoke-Schedule $s $true $true
            Send-Reply $ns 200 @{ ok = $true; id = $r.id; status = $r.status; detail = $r.detail; date = $r.date } $true $false
        }
        elseif ($route -eq 'POST /tick') {
            Assert-Auth $req
            $b = Get-JsonBody $req
            if ($b.dryRun -ne $true) { Fail-Http 403 'dry_run_required' }
            $res = @()
            foreach ($s in @($script:Cfg.schedules)) { if ($s) { $res += (Invoke-Schedule $s $true $false) } }
            $list = @($res | ForEach-Object { @{ id = $_.id; status = $_.status; detail = $_.detail } })
            Send-Reply $ns 200 @{ ok = $true; results = $list } $true $false
        }
        else {
            Send-Reply $ns 404 @{ ok = $false; error = 'not_found' } $true $false
        }
    } catch {
        $m = [string]$_.Exception.Message
        if ($m -match '^HTTP:(\d+):(.*)$') {
            Send-Reply $ns ([int]$matches[1]) @{ ok = $false; error = $matches[2] } $true $false
        } else {
            Write-Log ('요청 처리 오류: ' + (Short-Text $m))
            Send-Reply $ns 500 @{ ok = $false; error = 'internal' } $true $false
        }
    }
}

# ---------- self test (no printing, no network) ----------
function Invoke-SelfTest {
    $fails = @()
    $p = [DapCrypto]::Pbkdf2Sha256($script:Utf8.GetBytes('passwd'), $script:Utf8.GetBytes('salt'), 1, 32)
    $hex = ([BitConverter]::ToString($p)).Replace('-', '').ToLower()
    if ($hex -ne '55ac046e56e3089fec1691c22544b605f94185216dde0465e68b9d57c20dacbc') { $fails += 'pbkdf2' }
    $sealed = Seal-EncDoc '{"a":1,"s":"한글"}' 'test-pass'
    $back = Open-EncDoc $sealed 'test-pass'
    if ($back.s -ne '한글') { $fails += 'roundtrip' }
    try { [void](Open-EncDoc $sealed 'wrong-pass'); $fails += 'wrong_key_accepted' } catch { if ($_.Exception.Message -ne 'DECRYPT_FAILED') { $fails += 'wrong_key_msg' } }
    if ((Unprotect-Text (Protect-Text 'abc')) -ne 'abc') { $fails += 'dpapi' }
    try { [void](Test-Schedules @([pscustomobject]@{ id = 'x'; kind = 'delivery'; time = '25:00'; days = @(1); printer = 'x'; dateMode = 'today' }) @('x')); $fails += 'time_check' } catch { }
    $idx = [pscustomobject]@{ deliverySchedule = [pscustomobject]@{ entries = @([pscustomobject]@{ scheduleDate = '2026-11-02'; weekStart = '2026-11-02'; weekEnd = '2026-11-08'; revision = 1; file = 'delivery_20261102.enc.json' }) } }
    $c1 = Get-SourceChoice $idx 'delivery' 'latest' '2026-11-08' '2026-11-07'
    if (-not $c1.found -or $c1.date -ne '2026-11-02') { $fails += 'latest_week' }
    $c2 = Get-SourceChoice $idx 'delivery' 'latest' '2026-11-10' '2026-11-09'
    if ($c2.found) { $fails += 'old_week_accepted' }
    if ($fails.Count -eq 0) { Write-Output 'SELFTEST OK' } else { Write-Output ('SELFTEST FAIL: ' + ($fails -join ', ')) }
}

# ---------- main ----------
Initialize-Dirs
if ($SelfTest) { Invoke-SelfTest; exit 0 }

$mName = 'Local\DrawbreadAutoPrintAgent'
if ($Root) { $mName = 'Local\DrawbreadAutoPrintTest_' + ([Math]::Abs($Root.ToLower().GetHashCode())) }
$script:Mutex = New-Object Threading.Mutex($false, $mName)
$got = $false
try { $got = $script:Mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $got = $true }
if (-not $got) { Write-Log '이미 실행 중이라 종료'; exit 0 }

Write-Log ('에이전트 시작 v' + $script:Version + ' (PID ' + $PID + ')')
Write-Durable $script:PidPath ([string]$PID)
Load-Config
Load-Records
$changed = $false
foreach ($r in @($script:Records)) {
    if ($r.status -eq 'printing') {
        $r.status = 'unknown'
        $r.message = '재시작 전 인쇄 결과 불명 (자동 재시도 안 함)'
        $changed = $true
    }
}
if ($changed) { Save-Records }
$script:Token = Load-Secret $script:TokPath
# install.ps1 leaves this flag when the user chose to re-pair: keep schedules, pause, drop key/token
$resetFlag = Join-Path $script:Base 'reset_pair.flag'
if (Test-Path -LiteralPath $resetFlag) {
    Save-Config $script:Cfg.schedules $true
    $script:IdxCache = $null
    Remove-Item -LiteralPath $script:KeyPath, $script:TokPath -Force -ErrorAction SilentlyContinue
    $script:Token = $null
    Remove-Item -LiteralPath $resetFlag -Force
    Write-Log '다시 연결 요청: 예약 유지, 일시정지, 관리자 key 삭제'
}

$listener = New-Object System.Net.Sockets.TcpListener -ArgumentList ([System.Net.IPAddress]::Loopback), $Port
try { $listener.Start() } catch {
    Write-Log ('포트 ' + $Port + ' 를 열 수 없음: ' + (Short-Text $_.Exception.Message))
    exit 1
}
Write-Durable (Join-Path $script:Base 'agent.ready') ([string]$PID)
if (-not $script:Token) { New-PairingCode }

$lastTick = [DateTime]::MinValue
while ($true) {
    # 설치·제거 작업은 다른 PowerShell 프로세스를 강제 종료하지 않는다.
    if (Test-Path -LiteralPath (Join-Path $script:Base 'stop.flag')) {
        Write-Log '설치·제거 요청으로 안전하게 종료'
        break
    }
    $served = 0
    while ($listener.Pending() -and $served -lt 5) {
        $served++
        $client = $listener.AcceptTcpClient()
        try { Handle-Client $client } catch { Write-Log ('연결 처리 오류: ' + (Short-Text ([string]$_.Exception.Message))) } finally { $client.Close() }
    }
    if (((Get-UtcNow) - $lastTick).TotalSeconds -ge 30) {
        $lastTick = Get-UtcNow
        try { Invoke-SchedulerTick } catch { Write-Log ('스케줄 오류: ' + (Short-Text ([string]$_.Exception.Message))) }
    }
    if (-not $script:Token -and (Get-UtcNow) -gt $script:PairExpires) { New-PairingCode }
    Start-Sleep -Milliseconds 200
}
$listener.Stop()
try { $script:Mutex.ReleaseMutex() } catch { }
$script:Mutex.Dispose()
