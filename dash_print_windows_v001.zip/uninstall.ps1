﻿#requires -Version 5.1
# 조조 자동 인쇄 삭제. 연결 정보(관리자 key, 연결 값)와 예약 설정도 함께 지워집니다.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$title = '조조 자동 인쇄 삭제'
$dest = Join-Path $env:LOCALAPPDATA 'DrawbreadAutoPrint'

$ans = [System.Windows.Forms.MessageBox]::Show("자동 인쇄 프로그램을 삭제합니다.`r`n연결 정보(관리자 key, 연결 값)와 예약 설정도 함께 지워집니다.`r`n`r`n삭제할까요?", $title, 'YesNo', 'Question')
if ([string]$ans -ne 'Yes') { exit 0 }

try {
    $pidFile = Join-Path $dest 'agent.pid'
    if (Test-Path -LiteralPath $pidFile) {
        $raw = ([IO.File]::ReadAllText($pidFile)).Trim()
        $id = 0
        if ([int]::TryParse($raw, [ref]$id)) {
            $running = $null
            try { $running = [Diagnostics.Process]::GetProcessById($id) } catch { }
            if ($running -and -not $running.HasExited) {
                [IO.File]::WriteAllText((Join-Path $dest 'stop.flag'), 'stop')
                $finished = $false
                for ($j=0; $j -lt 40; $j++) {
                    Start-Sleep -Milliseconds 500
                    try { $finished = $running.HasExited } catch { $finished = $true }
                    if ($finished) { break }
                }
                if (-not $finished) { throw '인쇄 작업이 아직 끝나지 않았습니다. 잠시 뒤 다시 삭제해 주세요.' }
            }
        }
    }
    Start-Sleep -Milliseconds 800

    $vbs = Join-Path ([Environment]::GetFolderPath('Startup')) 'DrawbreadAutoPrint.vbs'
    if (Test-Path -LiteralPath $vbs) { Remove-Item -LiteralPath $vbs -Force }
    if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }

    [void][System.Windows.Forms.MessageBox]::Show('삭제가 끝났습니다.', $title, 'OK', 'Information')
} catch {
    [void][System.Windows.Forms.MessageBox]::Show(("삭제 중 문제가 생겼습니다.`r`n" + $_.Exception.Message), $title, 'OK', 'Error')
    exit 1
}
