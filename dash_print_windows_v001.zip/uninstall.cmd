@echo off
rem 조조 자동 인쇄 삭제: 이 파일을 더블클릭하세요.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
if errorlevel 1 pause
