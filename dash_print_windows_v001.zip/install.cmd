@echo off
rem 조조 자동 인쇄 설치: 압축을 푼 뒤 이 파일을 더블클릭하세요. 관리자 권한은 필요 없습니다.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 pause
