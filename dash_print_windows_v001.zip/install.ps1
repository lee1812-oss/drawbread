﻿#requires -Version 5.1
# 조조 자동 인쇄 설치 (관리자 권한 필요 없음). install.cmd 로 실행합니다.
# 인터넷에서 아무것도 내려받지 않고, 이 폴더의 agent.ps1 만 복사합니다.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$title = '조조 자동 인쇄 설치'

function Show-Msg([string]$text, [string]$icon) {
    [void][System.Windows.Forms.MessageBox]::Show($text, $title, 'OK', $icon)
}

# 내 계정, SYSTEM, 관리자 그룹만 접근 (상속 끊기)
function Set-FolderAcl([string]$path) {
    $me = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $null = & icacls.exe $path /inheritance:r /grant:r "*${me}:(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" /T /C /Q
    if ($LASTEXITCODE -ne 0) { throw '폴더 권한 설정에 실패했습니다.' }
}

function Stop-OldAgent([string]$dest) {
    $pidFile = Join-Path $dest 'agent.pid'
    if (-not (Test-Path -LiteralPath $pidFile)) { return }
    $raw = ([IO.File]::ReadAllText($pidFile)).Trim()
    $id = 0
    if (-not [int]::TryParse($raw, [ref]$id)) { return }
    try { $running = [Diagnostics.Process]::GetProcessById($id); if ($running.HasExited) { return } } catch { return }
    [IO.File]::WriteAllText((Join-Path $dest 'stop.flag'), 'stop')
    $finished = $false
    for ($j=0; $j -lt 40; $j++) {
        Start-Sleep -Milliseconds 500
        try { $finished = $running.HasExited } catch { $finished = $true }
        if ($finished) { break }
    }
    if (-not $finished) { throw '기존 인쇄 작업이 아직 끝나지 않았습니다. 잠시 뒤 다시 설치해 주세요.' }
}

try {
    $src = Join-Path $PSScriptRoot 'agent.ps1'
    if (-not (Test-Path -LiteralPath $src)) { throw 'agent.ps1 파일이 없습니다. zip 파일의 압축을 모두 푼 뒤 다시 실행하세요.' }

    $dest = Join-Path $env:LOCALAPPDATA 'DrawbreadAutoPrint'
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    Set-FolderAcl $dest
    Stop-OldAgent $dest
    $stopFlag = Join-Path $dest 'stop.flag'
    if (Test-Path -LiteralPath $stopFlag) { Remove-Item -LiteralPath $stopFlag -Force }

    # 프로그램 파일만 교체 (config.json, key.dpapi, token.dpapi 등 설정은 그대로 둡니다)
    $target = Join-Path $dest 'agent.ps1'
    $tmp = $target + '.new'
    Copy-Item -LiteralPath $src -Destination $tmp -Force
    Move-Item -LiteralPath $tmp -Destination $target -Force

    # 로그인 때 자동 실행 (관리자 권한 없이 시작 폴더에 등록)
    $startup = [Environment]::GetFolderPath('Startup')
    $vbs = Join-Path $startup 'DrawbreadAutoPrint.vbs'
    $line = 'sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""' + $target + '""", 0, False'
    $vbsText = 'Set sh = CreateObject("WScript.Shell")' + "`r`n" + $line + "`r`n"
    [IO.File]::WriteAllText($vbs, $vbsText, [Text.Encoding]::Unicode)

    # 지금 바로 시작 (이미 연결돼 있으면 코드 창은 뜨지 않음)
    $wasPaired = Test-Path -LiteralPath (Join-Path $dest 'token.dpapi')
    if ($wasPaired) {
        $ans = [System.Windows.Forms.MessageBox]::Show("이미 대시보드와 연결되어 있습니다.`r`n`r`n브라우저 연결을 잃어서 다시 연결해야 할 때만 '예'를 누르세요.`r`n예약 설정은 그대로 두고 일시정지됩니다.", $title, 'YesNo', 'Question')
        if ([string]$ans -eq 'Yes') {
            [IO.File]::WriteAllText((Join-Path $dest 'reset_pair.flag'), 'reset')
            $wasPaired = $false
        }
    }
    $pidFile = Join-Path $dest 'agent.pid'
    $before = ''
    if (Test-Path -LiteralPath $pidFile) { $before = ([IO.File]::ReadAllText($pidFile)).Trim() }
    $null = Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $target + '"')) -WindowStyle Hidden -PassThru

    $started = $false
    for ($i = 0; $i -lt 20; $i++) {
        Start-Sleep -Milliseconds 500
        if (Test-Path -LiteralPath $pidFile) {
            $now = ([IO.File]::ReadAllText($pidFile)).Trim()
            $readyFile = Join-Path $dest 'agent.ready'
            $ready = if (Test-Path -LiteralPath $readyFile) { ([IO.File]::ReadAllText($readyFile)).Trim() } else { '' }
            if ($now -and $now -ne $before -and $ready -eq $now) {
                try { $proc = [Diagnostics.Process]::GetProcessById([int]$now); $started = -not $proc.HasExited } catch { $started = $false }
                if ($started) { break }
            }
        }
    }
    if (-not $started) { throw '자동 인쇄 프로그램을 시작하지 못했습니다. PC를 다시 켠 뒤 install.cmd를 한 번 더 실행하세요.' }

    if ($wasPaired) {
        $msg = "설치(업데이트)가 끝났습니다.`r`n`r`n이미 대시보드와 연결되어 있어서 기존 설정은 그대로 유지됩니다."
    } else {
        $msg = "설치가 끝났습니다.`r`n`r`n잠시 뒤 '6자리 연결 코드' 창이 뜹니다.`r`n그 코드를 대시보드의 자동 인쇄 설정 화면 '연결 코드' 칸에 10분 안에 입력하세요.`r`n`r`n코드 창을 놓쳤으면 install.cmd를 한 번 더 실행하세요."
    }
    Show-Msg $msg 'Information'
} catch {
    Show-Msg ("설치에 실패했습니다.`r`n" + $_.Exception.Message) 'Error'
    exit 1
}
